package com.doodlejump.plateforms

import com.doodlejump.R
import com.doodlejump.Vector

class BasePlatform(ipos: Vector): Platform(ipos, R.drawable.baseplateform)