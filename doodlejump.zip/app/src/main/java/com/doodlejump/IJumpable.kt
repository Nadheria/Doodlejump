package com.doodlejump

interface IJumpable {
}