package com.doodlejump

interface IUpdate {
    fun update(game: GameManager)
}